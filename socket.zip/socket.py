class Socket :
    def run (self):
        print("hello from another world")