from cmd.plugins.world_compiler.world_compiler import WorldCompiler

class Compile:
    @classmethod
    def run(self):
        compiler = WorldCompiler()
        compiler.copy_world_to_temp()
        print("World copied to _temp_ folder.")
