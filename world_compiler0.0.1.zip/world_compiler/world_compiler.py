import os
import shutil
from zipfile import ZipFile
from utils.config import PylerConfig

class WorldCompiler:
    def __init__(self):
        self.config = PylerConfig()

    def copy_world_to_temp(self):
        world_folder = self.config.world_folder
        temp_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../_temp_")

        if not os.path.exists(temp_folder):
            os.makedirs(temp_folder)

        # Copy world folder
        for file_name in os.listdir(world_folder):
            if file_name in ["world_resource_pack_history.json", "level.dat_old", "world_behavior_pack_history.json"]:
                continue
            
            file_path = os.path.join(world_folder, file_name)
            if os.path.isfile(file_path):
                shutil.copy(file_path, temp_folder)
            elif os.path.isdir(file_path):
                shutil.copytree(file_path, os.path.join(temp_folder, file_name))

        # Copy behavior pack folder
        behavior_pack = self.config.behavior_pack
        temp_behavior_pack = os.path.join(temp_folder, "behavior_packs/BP")

        if os.path.exists(behavior_pack):
            if not os.path.exists(temp_behavior_pack):
                os.makedirs(temp_behavior_pack)

            for item in os.listdir(behavior_pack):
                src_item = os.path.join(behavior_pack, item)
                dst_item = os.path.join(temp_behavior_pack, item)

                if os.path.isdir(src_item):
                    shutil.copytree(src_item, dst_item, dirs_exist_ok=True)
                else:
                    shutil.copy2(src_item, dst_item)

        # Copy resource pack folder
        resource_pack = self.config.resource_pack
        temp_resource_pack = os.path.join(temp_folder, "resource_packs/RP")

        if os.path.exists(resource_pack):
            if not os.path.exists(temp_resource_pack):
                os.makedirs(temp_resource_pack)

            for item in os.listdir(resource_pack):
                src_item = os.path.join(resource_pack, item)
                dst_item = os.path.join(temp_resource_pack, item)

                if os.path.isdir(src_item):
                    shutil.copytree(src_item, dst_item, dirs_exist_ok=True)
                else:
                    shutil.copy2(src_item, dst_item)
                    
        # Create zip archive
        export_path = self.config.default_export
        if not os.path.exists(export_path):
            os.makedirs(export_path)
        zip_file = os.path.join(export_path, f"{self.config.name}.mcworld")

        with ZipFile(zip_file, 'w') as zip:
            for root, dirs, files in os.walk(temp_folder):
                for file in files:
                    zip.write(os.path.join(root, file), arcname=os.path.join(root[len(temp_folder)+1:], file))
        #Delete _temp_            
        shutil.rmtree(temp_folder)
